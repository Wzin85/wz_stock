import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// GitHub Pages: 저장소 이름이 wz_stock 이므로 base를 '/wz_stock/' 로 설정
export default defineConfig({
  plugins: [react()],
  base: '/wz_stock/',
})
